/*
Do not edit the contents of this file
*/
void dispatcher(FILE *fd, int harddrive);
